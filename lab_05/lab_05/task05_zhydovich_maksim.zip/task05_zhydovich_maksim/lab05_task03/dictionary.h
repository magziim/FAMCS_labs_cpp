#pragma once
#include<iostream>
#include<map>
#include<iostream>
#include<map>
#include<string>
#include<fstream>

using namespace std;

void dict_rep(string file, map<string, int>& vocabulary);   //dictionary of repetitions