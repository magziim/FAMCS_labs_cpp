#pragma once
#include <iostream>
#include <fstream>
#include <set>
#include <string>

using namespace std;

void zaprosy_txt(string file_name, multiset<int>& m);