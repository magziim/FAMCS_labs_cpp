#include<iostream>
#include "lab04_seminar.h"

using namespace std;

int main() {
  cout << "Enter the number: ";
  int n;
  cin >> n;

  cout << Sign(n);

  return 0; 
}